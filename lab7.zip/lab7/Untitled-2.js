function saveData() {
    let email, password;
    email=document.getElementById("email").value;
    password=document.getElementById("password").value;
    localStorage.setItem("email",email)
    localStorage.setItem("password",password)
}

function onSubmit(){
    let name, email, password, date;
    name= document.getElementById("name").value;
    email=document.getElementById("email").value;
    password=document.getElementById("password").value;
    date=document.getElementById("date").value;
    localStorage.setItem("email",email)
    localStorage.setItem("password",password)
    if(name == '' || email == '' || password == '' || date == '') {
        alert("Complete your registration");
    } else {
        saveData();
    }
}

function login() {
    if(document.getElementById("email1").value == '' || document.getElementById("password1").value  == '') {
        alert("Complete your registration");
    }
    if(document.getElementById("email1").value == localStorage.getItem("email") && document.getElementById("password1").value == localStorage.getItem("password")) {
        alert("Success logging");
        window.location.assign("https://yourdomain.com/successhttps://youtu.be/lh1d0B5JjTw");
    }
    if(document.getElementById("email1").value != localStorage.getItem("email") || document.getElementById("password1").value != localStorage.getItem("password")) {
        alert("Fail");
    }
}